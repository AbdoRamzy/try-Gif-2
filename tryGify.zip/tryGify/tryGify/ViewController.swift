//
//  ViewController.swift
//  tryGify
//
//  Created by salman on 3/4/19.
//  Copyright © 2019 salman. All rights reserved.
//

import UIKit
import ImageIO
import MobileCoreServices
import Photos


class ViewController: UIViewController {
    var arr: [UIImage] = []
    
    
    @IBOutlet weak var colorView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view, typically from a nib.
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (timer) in
            self.colorView.backgroundColor = UIColor.random()
            self.arr.append( self.colorView.takeScreenshot() )
        }
    }
    //: A UIKit based Playground for presenting user interface
    
    @IBAction func stop(_ sender: Any) {
        animatedGif(from: arr)
    }
    
    func animatedGif(from images: [UIImage]) {
        
        
        let fileProperties: CFDictionary = [kCGImagePropertyGIFDictionary as String: [kCGImagePropertyGIFLoopCount as String: 0]]  as CFDictionary
        let frameProperties: CFDictionary = [kCGImagePropertyGIFDictionary as String: [(kCGImagePropertyGIFDelayTime as String): 1.0]] as CFDictionary
        
        let documentsDirectoryURL: URL? = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL: URL? = documentsDirectoryURL?.appendingPathComponent("animated.gif")
        
        if let url = fileURL as CFURL? {
            
            if let destination = CGImageDestinationCreateWithURL(url, kUTTypeGIF, images.count, nil) {
                CGImageDestinationSetProperties(destination, fileProperties)
                for image in images {
                    if let cgImage = image.cgImage {
                        CGImageDestinationAddImage(destination, cgImage, frameProperties)
                    }
                }
                
                if CGImageDestinationFinalize(destination) {
                    
                    let data = try? Data(contentsOf: fileURL!)
                    guard let mData = data else { return }
                    PHPhotoLibrary.shared().performChanges({
                            PHAssetCreationRequest.forAsset().addResource(with: .photo, data: mData, options: nil)
                        }) { success, error in
                            guard success else {
                                print("failed to save gif \(error)")
                                return
                            }
                                print("successfully saved gif")
                        }
                        
                    }
                    
                    
                } else { print("failed") }
            
//                if !CGImageDestinationFinalize(destination) {
//                    print("Failed to finalize the image destination")
//                }
                print("Url = \(fileURL)")
            
        }
    }
    
    
//    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
//
//        if let error = error {
//            print("Error Saving ARKit Scene \(error)")
//        } else {
//            print("ARKit Scene Successfully Saved")
//        }
//    }

    
}


extension UIView {
    
    func takeScreenshot() -> UIImage {
        
        // Begin context
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, false, UIScreen.main.scale)
        
        // Draw view in that context
        drawHierarchy(in: self.bounds, afterScreenUpdates: true)
        
        // And finally, get image
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        if (image != nil)
        {
            return image!
        }
        return UIImage()
    }
}

extension UIColor {
    static func random() -> UIColor {
        return UIColor(red:   .random(),
                       green: .random(),
                       blue:  .random(),
                       alpha: 1.0)
    }
}

extension CGFloat {
    static func random() -> CGFloat {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
}
